#include "Graph.h"
#include <string>
#include <fstream>
#include <iostream>
#include <cstring>
#include <queue>

Graph::Graph(std::string fileToOpen){
    startNode = NULL;
    numOfNodes = 0;
    masterList.resize(0);
    initialize(fileToOpen);
}

void Graph::initialize(std::string fileToOpen){
    std::ifstream fin(fileToOpen.c_str());
    std::string stringToParse;
    char currentNodeValue;
    char adjacentNodeValue;
    Node* tempNode = NULL;
    Node* placeHolder = NULL;
    int adjacencyX = 0;
    int adjacencyY = 0;

    if(fin.is_open()){
        fin >> numOfNodes;
        adjacencyMatrix.resize(numOfNodes);
        for(int i = 0; i < numOfNodes; i++){
            adjacencyMatrix[i].resize(numOfNodes, 0);
        }

        while(!fin.eof()){
            tempNode = NULL; //resets temp node for checks
            placeHolder = NULL; //resets pointer for linking adjacent nodes
            getline(fin, stringToParse);
            if(!stringToParse.empty()){
                currentNodeValue = stringToParse[0];
                //check if currentNodeValue is in the Master List, and if not, add it.

                int i = 0;
                for(it = masterList.begin(); it < masterList.end(); it++, i++){
                    //if the currentNodeValue is, grab the Node* from the list
                    if(currentNodeValue == masterList[i]->letter){
                        tempNode = masterList[i];
                        break;
                    }
                }



                if(tempNode == NULL){
                    //the currentNodeValue was not in the master list, so we add it
                    tempNode = new Node(currentNodeValue);
                    tempNode->nodeNumber = masterList.size();
                    adjacencyX = tempNode->nodeNumber;
                    masterList.push_back(tempNode);
                }


                //if the starting node is null, assign the first node added to the Master List
                if(startNode == NULL){
                    startNode = tempNode;
                }




                //starts at one because we already grab the first value from this line in the file
                for(int i = 1; i < strlen(stringToParse.c_str()); i++){
                    bool nodeInMaster = false;
                    adjacentNodeValue = stringToParse[i];

                    //if the node does not contain a letter, we discard it

                    if(isalpha(adjacentNodeValue)){
                        //first check if it's in the master list already, and if so, grab it
                        int j = 0;
                        for(it = masterList.begin(); it < masterList.end(); it++, j++){
                        //if the adjacentNodeValue is, grab the Node* from the list
                            if(adjacentNodeValue == masterList[j]->letter){
                                nodeInMaster = true; //we found the node in the master list

                                //add the node to the current node's adjacent list
                                tempNode->addAdjacent(masterList[j]);
                                adjacencyY = tempNode->nodeNumber;

                                adjacencyMatrix[adjacencyY][adjacencyX] += 1;
                                break;
                            }
                        }//for
                        if(nodeInMaster == false){
                            //adjacent node was not found in master, so make new node and add to master
                            placeHolder = new Node(adjacentNodeValue);

                            placeHolder->nodeNumber = masterList.size();
                            masterList.push_back(placeHolder);

                            //then add to the current node's adjacent list
                            tempNode->addAdjacent(placeHolder);
                            placeHolder = NULL;
                        }
                    }

                } //for

            }
        }//while

    } else{
        std::cout << fileToOpen << " was not found or does not exist." << std::endl << std::endl;
    }
}


void Graph::printGraph(){
    int i = 0;
    Node* tempNode = NULL;
    for(it = masterList.begin(); it < masterList.end(); it++, i++){
        tempNode = masterList[i];
        tempNode->printNode();
    }
}


void Graph::depthFirst(Node* currentNode){
    currentNode->isVisited = true;

    std::cout << "Current Node is " << currentNode->letter << std::endl;
    int i = 0;

    for(currentNode->it = currentNode->adjacentList.begin();
        currentNode->it < currentNode->adjacentList.end(); currentNode->it++, i++){

        if(currentNode->adjacentList[i]->isVisited == false){
            //if the node hasn't been visited, recurse
            depthFirst(currentNode->adjacentList[i]);
        }
    }

}


void Graph::breadthFirst(Node* startNode){
    std::queue <Node*> nodeQueue;
    Node* x;
    Node* y;

    startNode->isVisited = true;
    nodeQueue.push(startNode);

    while(!nodeQueue.empty()){
        x = nodeQueue.front();
        nodeQueue.pop(); // grabs next node to check adjacencyList
        std::cout << "Current node is " << x->letter << std::endl;
        int i = 0;
        for(x->it = x->adjacentList.begin(); x->it < x->adjacentList.end(); x->it++, i++){
            if(x->adjacentList[i]->isVisited == false){
                x->adjacentList[i]->isVisited = true;
                nodeQueue.push(x->adjacentList[i]);
            }
        }
    }


}


void Graph::printMatrix(){

    for(int i = 0; i < numOfNodes; i++){
        for(int j = 0; j < numOfNodes; j++){

            std::cout << adjacencyMatrix[i][j] << " ";
        }
        std::cout << std::endl;
    }
}
