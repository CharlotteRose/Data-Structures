#ifndef GRAPH_H
#define GRAPH_H
#include <vector>
#include <string>
#include "Node.h"


class Graph{

    public:
        Graph(std::string fileToOpen);
        void initialize(std::string fileToOpen);
        void printGraph();
        void printMatrix();
        void breadthFirst(Node* currentNode);
        void depthFirst(Node* currentNode);
        std::vector <Node*> masterList;
        std::vector <Node*>::iterator it; //iterator to allow access to master list

        std::vector <std::vector <int> > adjacencyMatrix;

        Node* startNode;
        int numOfNodes;

        void resetChecks();
};

#endif // GRAPH_H
