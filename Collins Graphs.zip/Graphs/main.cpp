#include "Graph.h"


int main(){
    Graph testGraph("Graph.txt");
    //testGraph.initialize("Graph.txt");
    testGraph.printGraph();
    testGraph.printMatrix();

    testGraph.breadthFirst(testGraph.startNode);
    return 0;
}
