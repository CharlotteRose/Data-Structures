#include "Compiler.h"

void Compiler::compileFile(std::string fileName){
    stripFile(fileName);

}
