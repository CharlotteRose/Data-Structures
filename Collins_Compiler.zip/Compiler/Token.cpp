#include "Token.h"

Token::Token(){
    tokenType = ERROR;
    symbol = ' ';
    identifier = "";
    stringVal = "";
    intVal = 0;
    keyword = "";
}
