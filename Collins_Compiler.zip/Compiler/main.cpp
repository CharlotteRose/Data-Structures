#include "Compiler.h"

int main(){
    Compiler testCompiler;
    testCompiler.compileFile("main.jack");
}
