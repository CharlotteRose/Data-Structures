#include "VirtualMachine.h"

int main(){
    std::string fileName;

    fileName = "SimpleFunction";
    VirtualMachine VirtualMachine(fileName);
}
