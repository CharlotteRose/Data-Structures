#include "VirtualMachine.h"

int main(){
    std::string fileName;

    fileName = "Sys";
    VirtualMachine VirtualMachine(fileName);
}
